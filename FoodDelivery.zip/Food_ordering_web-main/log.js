document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form refresh

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    // Get stored user credentials from localStorage
    const storedEmail = localStorage.getItem("userEmail");
    const storedPassword = localStorage.getItem("userPassword");

    // Validate login details
    if (email === storedEmail && password === storedPassword) {
        alert("Login Successful! Redirecting to home page...");
        window.location.href = "index.html"; // Redirect to home page after login
    } else {
        alert("Invalid email or password. Please try again.");
    }
});
