FOOD DELIVERY WEB APPLICATION - MSD PROJECT
===========================================

Project Title:
Online Food Delivery Web Application

Course:
Mean stack Development (MSD)

Developed By:
[S.Sahithi,G.Niharika]
[4254 / 4217]
[VNITSW]

--------------------------------------------------------------------------------
PROJECT OVERVIEW:

This is a full-stack web application simulating an online food delivery system.
Users can browse restaurants, view menus, add items to the cart, and place orders.
The frontend is developed using HTML, CSS, and JavaScript, while the backend is
powered by Node.js, Express.js, and MongoDB for data storage.

--------------------------------------------------------------------------------
TECHNOLOGIES USED

Frontend:
- HTML5
- CSS3
- JavaScript (Vanilla JS)

Backend:
- Node.js
- Express.js
- MongoDB (via Mongoose)
- EJS (for templating, if used)
- Body-parser, dotenv, and other NPM packages

--------------------------------------------------------------------------------
FEATURES:
✔ Responsive UI for food browsing and ordering  
✔ Restaurant and menu listing  
✔ Add to Cart and Order functionality  
✔ Order Confirmation and History  
✔ MongoDB-based persistent data storage  
✔ RESTful APIs for communication between frontend and backend  
✔ Basic user authentication (if implemented)

--------------------------------------------------------------------------------
FOLDER STRUCTURE:
/food-delivery-app/
│
├── /frontend/
│   ├── index.html
│   ├── login.html
│   ├── signup.html
│   ├── /css/
│   │   └── style.css
│   ├── /js/
│   │   └── script.js
│   └── /images/
│       └── [All UI images]
│
├── /backend/
│   ├── app.js                 --> Main server file
│   ├── /routes/
│   │   └── api.js             --> All API endpoints
│   ├── /models/
│   │   └── orderModel.js      --> MongoDB schema for orders
│   │   └── userModel.js       --> MongoDB schema for users (if used)
│   ├── /controllers/
│   │   └── orderController.js
│   ├── /views/ (optional)     --> For EJS templates
│   ├── /config/
│   │   └── db.js              --> MongoDB connection
│   └── .env                   --> Environment variables (PORT, DB URI, etc.)
│
└── package.json              --> Node project metadata

--------------------------------------------------------------------------------
INSTALLATION & RUNNING INSTRUCTIONS:
1. Clone or download this repository.

2. Navigate to the backend folder and install dependencies:
   $ cd backend
   $ npm install

3. Create a `.env` file inside `/backend/` and add:
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/foodDeliveryDB

4. Start the backend server:
   $ npm start

5. Open `/frontend/index.html` in a web browser to access the frontend.

*NOTE:* Make sure MongoDB is running locally, or replace the URI with your Atlas connection string.

--------------------------------------------------------------------------------
API ENDPOINTS (SAMPLE):

POST /api/orders
  - Place a new food order

GET /api/orders
  - Fetch all orders

POST /api/users (optional)
  - Register new user

--------------------------------------------------------------------------------
LIMITATIONS:
- Basic frontend validations; no payment integration
- No advanced security/authentication
- Not optimized for production deployment

--------------------------------------------------------------------------------
FUTURE IMPROVEMENTS:

- Add user authentication with JWT
- Implement payment gateway integration (Razorpay/Stripe)
- Admin dashboard for order management
- Deploy with Docker and host on cloud platform

--------------------------------------------------------------------------------
LICENSE:

This project is developed as part of the academic MSD curriculum and is free for educational purposes.

